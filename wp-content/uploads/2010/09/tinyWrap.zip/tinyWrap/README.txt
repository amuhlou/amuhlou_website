TinyMCE Wrap DIV Plugin

This is an unofficial Wordpress plugin that adds a <div> button for the TinyMCE visual editor which wraps the selected text in a div.

The plugin was combined by Amy Bibbings (amy@amuhlou.com) based on two resources:

A forum post by Peter Wilson (petew@yellowhawk.co.uk), showing a plugin he created: http://tinymce.moxiecode.com/punbb/viewtopic.php?pid=73468

A blog post by Brett Terpstra explaining how to add a TinyMCE button in wordpress: http://brettterpstra.com/adding-a-tinymce-button/

DIV button by Amy Bibbings.

Version 1.0, Released September 7, 2010 for WP 2.5

Version 1.1, Released August 20, 2011 tested on WP 3.2.1
- fixed relative paths
- fixed issue where a double div button would show in some cases